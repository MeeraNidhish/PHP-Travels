package com.php.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassAdmin;

public class Website extends BaseClassAdmin {
	
	WebDriver driver;

	@FindBy(linkText="Website")
	private WebElement website;

	public Website(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	
	public void ClickWebsite() throws InterruptedException
	{
		Thread.sleep(4000);
		website.click();
		Thread.sleep(4000);
	}
	
}


