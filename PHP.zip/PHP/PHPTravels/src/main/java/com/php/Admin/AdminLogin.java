package com.php.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassAdmin;

public class AdminLogin extends BaseClassAdmin {

	
WebDriver driver;

@FindBy(xpath="//input[@name='email']")
private WebElement Email;

@FindBy(xpath="//input[@name='password']")
private WebElement Password;

@FindBy(xpath="//button[@type='submit']")
private WebElement LoginButton;
@FindBy(xpath="//p[text()='The Email field must contain a valid email address.']")
private WebElement invalid;

	public AdminLogin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	public void EnterEmail(Object AdminEmail) throws InterruptedException
	{
		Email.sendKeys(AdminEmail.toString() );
		
	}
	
	public void EnterPassword(Object AdminPassword) throws InterruptedException
	{
		Password.sendKeys( AdminPassword.toString() );
		
	}
	
	public void ClickLogin() throws InterruptedException
	{
		
		LoginButton.click();
		Thread.sleep(6000);
	}
	public boolean Errormessage() throws InterruptedException
	{
		Thread.sleep(1000);
	
	boolean ErrorMsg=invalid.isDisplayed();
	return ErrorMsg;
	}
	public void ClearInvalidEmail(Object AdminEmail) throws InterruptedException
	{
		Email.clear();
		Thread.sleep(2000);
		Password.clear();
		Thread.sleep(2000);
		
	}
}
