package com.php.Agent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.Base.BaseClassCustomer;

public class AgentUpdate extends BaseClassCustomer{

	
	
	WebDriver driver;
	
	@FindBy(xpath="//button[@id='currency'and@class='btn btn-default dropdown-toggle waves-effect']")
	private WebElement select;
	
	//@FindBy(xpath="//a[@href='https://phptravels.net/currency-INR']")
	@FindBy(xpath="//a[@class='dropdown-item waves-effect'and text()=' INR']")
	private WebElement selectINR;
	
	@FindBy(xpath="//a[text()=' Logout' and @class=' waves-effect']|//li[@class=' page-active']")
	private WebElement logout;
	
	
	
	public AgentUpdate(WebDriver driver) {
		// TODO Auto-generated constructor stub
	
		this.driver=driver;
		PageFactory.initElements(driver,this);
		}
	public void selectUsd() throws InterruptedException
	{
		select.click();
		Thread.sleep(4000);
		 //Actions action = new Actions(driver);
		// action.moveToElement(selectINR).build().perform();
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",  selectINR);
		Thread.sleep(4000);
		 selectINR.click();
		
		Thread.sleep(4000);
		
			
	}
	 public void Logout()
	 {
		 logout.click();
	 }
	
}
