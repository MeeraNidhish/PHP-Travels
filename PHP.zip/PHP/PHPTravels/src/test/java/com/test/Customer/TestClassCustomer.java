package com.test.Customer;

import java.io.IOException;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import org.testng.annotations.Test;

import com.php.Admin.AdminLogin;
import com.php.Base.BaseClassCustomer;
import com.php.Customer.CustomerDashboard;
import com.php.Customer.CustomerLogin;
import com.php.utilities.ExcelUtility;

public class TestClassCustomer extends BaseClassCustomer {
	CustomerLogin custloginobj;
	CustomerDashboard custobj;
@Test(priority = 1,description="Login to the Customer Dashboard page with invalid email and valid password")
	
	public void LogininToDashboardwithInvalidEmail() throws IOException, InterruptedException {
		
		custloginobj=new CustomerLogin(driver);
		
Object CustomerEmail=ExcelUtility.GetCellData(1, 3,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object CustomerPassword=ExcelUtility.GetCellData(1,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		custloginobj.EnterEmail(CustomerEmail);
		Thread.sleep(2000);
		custloginobj.EnterPassword(CustomerPassword);
		custloginobj.ClickLogin();
		Thread.sleep(3000);
		custloginobj.ClearInvalidEmail(CustomerEmail);
		custloginobj.ClearInvalidEmail(CustomerPassword);
		Thread.sleep(2000);
		
		
}
@Test(priority = 2,description="Login to the Admin Dashboard page with valid email and password")
	
	public void LogininToDashboard() throws IOException, InterruptedException {
		
		custloginobj=new CustomerLogin(driver);
		
Object CustomerEmail=ExcelUtility.GetCellData(2, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
		
		Object CustomerPassword=ExcelUtility.GetCellData(2,2,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
		custloginobj.EnterEmail(CustomerEmail);
		custloginobj.EnterPassword(CustomerPassword);
		custloginobj.ClickLogin();
		Thread.sleep(7000);
}
@Test(priority = 3 ,description="VERIFYING THE LINK MYBOOKINGS AND VIEW THE VOUCHER")
public void VerifyingLinkMyBookings() throws InterruptedException
{
	custobj=new CustomerDashboard(driver);
	custobj.clickMyBookings();
	Thread.sleep(4000);
	custobj.clickViewVoucher();
	Thread.sleep(4000);
	//close the invoice window
		Set<String> wnd1 = driver.getWindowHandles();
		
		//window handles iteration
		Iterator<String> i1 = wnd1.iterator();
		String prntw1 = i1.next();
		String popwnd1 = i1.next();
		//switching pop up window handle id
		driver.switchTo().window(popwnd1);
		driver.close();
		driver.switchTo().window(prntw1);
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(5000);
}
@Test(priority = 4,description="VERIFYING THE LINK ADD FUNDS AND MAKE AN PAYMENT OF USD 50 USING PAYPAL")
public void VerifyingAddFunds() throws InterruptedException
{
	custobj.clickAddFunds();
	Thread.sleep(3000);
	custobj.selectPayPal();
	Thread.sleep(5000);
	
	
	}
@Test(priority = 5 ,description="VERIFYING THE LINK MY PROFILE AND UPDATE THE ADDRESS FIELD")
public void verifyingMyProfile() throws InterruptedException, IOException
{
	Random random = new Random();
int number = random.nextInt(10000);
Object Address= number+ExcelUtility.GetCellData(1, 4,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelHome.xlsx", 0);
	
custobj.clickMyProfile();	
Thread.sleep(3000);
custobj.UpdateAddress(Address);
Thread.sleep(5000);
custobj.GetNotification();


	}
@Test(priority = 6 ,description="VERIFYING THE LINK LOGOUT")
public void LogoutByCustomer()
{
	custobj.Logout();
	}



}
